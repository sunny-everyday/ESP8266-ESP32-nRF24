/*
 *  SoftwareSerial(int receivePin, int transmitPin, bool inverse_logic = false, unsigned int buffSize = 64);
 *  // Disable or enable interrupts on the rx pin
 *   void enableRx(bool on);
 * 
 * 
 * 
 */

#include <SoftwareSerial.h>\\���ذ�װzip�⣬
SoftwareSerial TempSerial(25, 26 , false , 1024);// RX:25  TX:26  �͵�ƽ��ʼ  1024�ֽڻ���
char teststring;
void setup() {
  // put your setup code here, to run once:
  Serial.begin(115200);
  TempSerial.begin(9600);
  delay(1000);
  Serial.printf("ESP32 Virtual Serial Test GPIO 25 26 9600bps\r\n" );
}

void loop() {
  // put your main code here, to run repeatedly:
  delay(1000);
  Serial.printf("Serial2  Test GPIO 25 26 9600bps\r\n");
  TempSerial.printf("I'm Virtual Serial\r\n");

  if( TempSerial.available()>0 ){
    Serial.printf("Serial2 Read Data:\r\n");
    do{
      teststring = TempSerial.read();
      Serial.print( teststring );
    }while(TempSerial.available()>0);
    Serial.printf("\r\n");
  }
}