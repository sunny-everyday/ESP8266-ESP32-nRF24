:mod:`_thread` -- multithreading support
========================================

.. module:: _thread
   :synopsis: multithreading support

|see_cpython_module| :mod:`python:_thread`.

This module implements multithreading support.

This module is highly experimental and its API is not yet fully settled
and not yet described in this documentation.
