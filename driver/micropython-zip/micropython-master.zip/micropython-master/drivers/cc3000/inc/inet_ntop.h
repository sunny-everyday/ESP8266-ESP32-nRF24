#ifndef __INET_NTOP_H
#define __INET_NTOP_H
char *inet_ntop(int af, const void *addr, char *buf, size_t size);
#endif /* __INET_NTOP_H */
