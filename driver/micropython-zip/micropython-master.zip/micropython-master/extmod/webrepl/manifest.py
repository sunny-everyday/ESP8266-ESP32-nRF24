freeze(".", ("webrepl.py", "webrepl_setup.py", "websocket_helper.py"))
