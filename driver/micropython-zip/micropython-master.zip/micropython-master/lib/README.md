This directory contains third-party, low-level C libraries and SDKs.
Libraries that do not target any specific platform are generally chosen
based on them being independent and efficient.
